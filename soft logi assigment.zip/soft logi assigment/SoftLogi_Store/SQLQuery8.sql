USE [SoftLogi_DB]
GO

INSERT INTO [dbo].[Products]
           ([Name]
           ,[Price]
           ,[Quantity]
           ,[Tags])
     VALUES
           (<Name, nvarchar(100),>
           ,<Price, int,>
           ,<Quantity, int,>
           ,<Tags, nvarchar(100),>)
GO


INSERT INTO Products (Id, Name, Price, Quantity, Tags)
VALUES
  (6, 'Dumi Black', 32.99, 12, 'dumi, black, classic'),
  (7, 'Dumi Purple', 36.99, 4, 'dumi, purple, trendy'),
  (8, 'Dumi Orange', 28.99, 9, 'dumi, orange, vibrant'),
  (9, 'Dumi Pink', 31.99, 6, 'dumi, pink, cute'),
  (10, 'Dumi White', 25.99, 15, 'dumi, white, minimalist'),
  (11, 'Dumi Limited Edition', 99.99, 2, 'dumi, limited, exclusive'),
  (12, 'Dumi Eco-Friendly', 38.99, 8, 'dumi, eco, sustainable'),
  (13, 'Dumi Vintage', 44.99, 5, 'dumi, vintage, retro'),
  (14, 'Dumi Waterproof', 42.99, 7, 'dumi, waterproof, outdoor'),
  (15, 'Dumi Wireless', 59.99, 3, 'dumi, wireless, bluetooth'),
  (16, 'Dumi Gaming', 64.99, 4, 'dumi, gaming, controller'),
  (17, 'Dumi Travel', 39.99, 10, 'dumi, travel, portable'),
  (18, 'Dumi Customizable', 45.99, 6, 'dumi, customize, personalized'),
  (19, 'Dumi Solar-Powered', 52.99, 5, 'dumi, solar, renewable'),
  (20, 'Dumi Smart', 69.99, 3, 'dumi, smart, technology');