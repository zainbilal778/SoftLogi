﻿
using System.ComponentModel.DataAnnotations;

namespace SoftLogi_Store.Models
{
	public class Product
	{
		public int Id { get; set; }
		[MaxLength(100)]
		public string Name { get; set; } = "";
		[MaxLength(100)]
		public int Price { get; set; }
		[MaxLength(100)]
		public int Quantity { get; set; }
		[MaxLength(100)]
		public string Tags { get; set; } = "";



	}
}
