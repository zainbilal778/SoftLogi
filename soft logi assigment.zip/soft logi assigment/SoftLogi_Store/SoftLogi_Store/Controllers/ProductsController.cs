﻿using Microsoft.AspNetCore.Mvc;
using SoftLogi_Store.Models;
using SoftLogi_Store.services;

namespace SoftLogi_Store.Controllers
{
	public class ProductsController : Controller
	{
		private readonly ApplicationDbcontext context;

		public ProductsController(ApplicationDbcontext context)
		{
			this.context = context;
		}
		public IActionResult Index()
		{
			var products = context.Products.OrderByDescending(p => p.Id).ToList();
			return View(products);
		}

        public IActionResult Create()
		{
			return View();
		}
		[HttpPost]
		public IActionResult Create(ProductDto productDto)
		{
			if (productDto == null) {
			return View();
		}

	}
}
